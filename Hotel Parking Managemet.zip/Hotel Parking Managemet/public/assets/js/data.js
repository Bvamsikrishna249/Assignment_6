document.addEventListener('DOMContentLoaded', () => {
    const tableBody = document.querySelector('#datagohere');
    const storedEntries = JSON.parse(localStorage.getItem('entries')) || [];

    // Function to display entries from localStorage
    function displayEntries() {
        tableBody.innerHTML = ''; // Clear existing data before adding new
        storedEntries.forEach((entry, index) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td><img src="${entry.photo}" alt="User Photo" width="80" /></td>
                <td>${entry.name}</td>
                <td>${entry.mobile}</td>
                <td>${entry.car}</td>
                <td>${entry.color}</td>
                <td>${entry.licensePlate}</td>
                <td>${entry.parkingSlot}</td>
                <td>${entry.parkingFloor}</td>
                <td>${entry.entryDate}</td>
                <td>${entry.entryTime}</td>
                <td>${entry.exitDate}</td>
                <td>${calculateDuration(entry.entryDate, entry.entryTime, entry.exitDate)} hours</td>
                <td>${entry.vehicleType}</td>
                <td>${entry.type}</td>
                <td><button class="delete-btn" onclick="deleteEntry(${index}, '${entry.mobile}')">Delete</button></td>
            `;
            tableBody.appendChild(row);
        });
    }

    // Calculate duration function
    function calculateDuration(entryDate, entryTime, exitDate) {
        const entryDateTime = new Date(`${entryDate}T${entryTime}`);
        const exitDateTime = new Date(`${exitDate}T23:59`);
        const diffMs = exitDateTime - entryDateTime;
        const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
        return diffHours;
    }

    // Call the function to display entries on page load
    displayEntries();

    // Function to delete entry
    window.deleteEntry = function(index, mobile) {
        const password = prompt("Please enter your password to confirm deletion:");
        const correctPassword = "yourPassword"; // Replace with your actual password

        if (password === correctPassword) {
            storedEntries.splice(index, 1); // Remove the entry from the array
            localStorage.setItem('entries', JSON.stringify(storedEntries)); // Update localStorage
            alert(`Entry with mobile number ${mobile} has been deleted.`);
            displayEntries(); // Refresh the displayed entries
        } else {
            alert('Incorrect password. Entry not deleted.');
        }
    }
});
