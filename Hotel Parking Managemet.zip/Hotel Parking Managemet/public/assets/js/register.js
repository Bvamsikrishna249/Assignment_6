document.getElementById('registration-form').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent form submission
  
    // Predefined credentials for validation
    const validCredentials = {
        staff: [
            { username: 'staffUser', password: 'staffPassword' }
        ],
        customer: [
            { username: 'lalsrivamsi', password: 'Lal@2005' },
            { username: 'vamsikrishna', password: 'Vamsi@2004' },
            { username: 'saisandeep', password: 'Sandeep@2004' },
            { username: 'sriram', password: 'Sriram@2004' },
            { username: 'khaleel', password: 'Khaleel@2004' },
            { username: 'ajay', password: 'Ajay@2004' }
        ]
    };
  
    // Get user input values
    const username = document.getElementById('reg-username').value;
    const password = document.getElementById('reg-password').value;
    const accountType = document.getElementById('reg-type').value;
  
    // Function to check if the user credentials are valid for the selected account type
    function validateCredentials(accountType, username, password) {
        return validCredentials[accountType]?.some(
            (user) => user.username === username && user.password === password
        );
    }
  
    // Validate user credentials based on the selected account type
    if (validateCredentials(accountType, username, password)) {
        alert('Registration successful! Redirecting to login page...');
        // Redirect to dashboard or home page
        window.location.href = './index.html'; // Change URL as needed
    } else {
        alert('Invalid credentials! Please check your username, password, or account type.');
    }
  });
  