const express = require('express');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');

const app = express();
const port = 3000;

// Middleware to parse JSON and form-data requests
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files (HTML, CSS, JS)
app.use(express.static(path.join(__dirname, 'public')));

// In-memory store for users and parking entries
let users = [];
let entries = [];

// Multer setup for file uploads (e.g., user photos)
const storage = multer.memoryStorage();
const upload = multer({ storage });

// Serve the HTML pages
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'data.html'));
});

app.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'register.html'));
});

// API route to register a user
app.post('/register', (req, res) => {
    const { username, password, accountType } = req.body;
    if (!username || !password) {
        return res.status(400).send('All fields are required');
    }
    users.push({ username, password, accountType });
    res.send('Registration successful');
});

// API route to get parking entries
app.get('/entries', (req, res) => {
    res.json(entries);
});

// API route to add a parking entry
app.post('/entries', upload.single('photo'), (req, res) => {
    const entry = req.body;
    const photo = req.file ? req.file.buffer.toString('base64') : null; // Convert photo to base64
    entry.photo = photo;
    entry.duration = calculateDuration(entry.entryDate, entry.entryTime, entry.exitDate); // Calculate duration
    entries.push(entry);
    res.send('Entry added successfully');
});

// API route to delete a parking entry
app.delete('/entries/:index', (req, res) => {
    const index = parseInt(req.params.index);
    if (index >= 0 && index < entries.length) {
        entries.splice(index, 1);
        res.send('Entry deleted successfully');
    } else {
        res.status(404).send('Entry not found');
    }
});

// Utility function to calculate duration
function calculateDuration(entryDate, entryTime, exitDate) {
    const entryDateTime = new Date(`${entryDate}T${entryTime}`);
    const exitDateTime = new Date(`${exitDate}T23:59`);
    const diffMs = exitDateTime - entryDateTime;
    return Math.floor(diffMs / (1000 * 60 * 60)); // Return in hours
}

// Start the server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
