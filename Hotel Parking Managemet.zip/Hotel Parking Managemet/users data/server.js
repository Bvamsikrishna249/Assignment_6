const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware to serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Set view engine to Pug
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

// Define routes
app.get('/', (req, res) => {
  res.render('index'); // Render index.pug
});

app.get('/about', (req, res) => {
  res.render('about'); // Render about.pug
});

app.get('/data', (req, res) => {
  res.render('data'); // Render data.pug
});

app.get('/registration', (req, res) => {
  res.render('registration'); // Render registration.pug
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
